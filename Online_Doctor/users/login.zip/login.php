<?php
	
	include('../includes/init.php');
	
	
	
	if(empty($_POST) == false)
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if(empty($username) == true || empty($password) == true)
		{
			$errors[]='you need to enter username and password both';
		}	
		else if(user_exists($username) == false)
		{
			$errors[]='we can\'t find that username. Have you registered? ';
		}
		else if(user_active($username) == false)
		{
			$errors[]='You haven\'t activated your account! ';
		}
		else
		{
			$login = login($username,$password);
			if($login == false)
			{
				$errors[]='That username/password combination is incorrect! ';
			}
			else
			{
				$_SESSION['user_id']  = $login;
				header('location: index.php');
				exit();
			}
		}
		//print_r($errors);
	}
?>